package com.ot9.empcrud;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysql");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

//		Employee emp = new Employee(123, "suresh", 50000, "banglore");
//		em.persist(emp);

		Employee emp = em.find(Employee.class, 123);
		System.out.println(emp);

//		emp.setEmpName("ram");
//		emp.setEmpAdd("hyderabad");
//		emp.setEmpSal(85000);
		// em.merge(emp);

		em.remove(emp);
		em.getTransaction().commit();

	}

}
