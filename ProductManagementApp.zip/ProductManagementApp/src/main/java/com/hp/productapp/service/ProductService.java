package com.hp.productapp.service;

import java.util.List;

import com.hp.productapp.entity.Product;

public interface ProductService {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String deleteProduct(int productId);

	public abstract Product getProduct(int productId);

	public abstract List<Product> GetAllProducts();

	public abstract List<Product> getAllProductsByPriceRange(int intialPrice, int finalPrice);

	public abstract List<Product> getAllProductsByCategory(String category);
}
