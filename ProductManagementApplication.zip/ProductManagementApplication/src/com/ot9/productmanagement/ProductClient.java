package com.ot9.productmanagement;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class ProductClient {

	public static void main(String[] args) {
		int productId;
		String productName;
		int productPrice;
		String productCategory;
		Product product;
		Scanner scan = new Scanner(System.in);
		HashMap<Integer, Product> products = new HashMap<Integer, Product>();
		while (true) {
			System.out.println("**********Product Management Application************");
			System.out.println("1) Add product");
			System.out.println("2) update product");
			System.out.println("3) delete product");
			System.out.println("4) get product by id");
			System.out.println("5) getall products");
			System.out.println("6) getall products by price range");
			System.out.println("7) get all products by category");
			System.out.println("8) exit");

			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Details To Add Product ");
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				System.out.println("Enter ProductName:");
				productName = scan.next();
				System.out.println("Enter ProductPrice:");
				productPrice = scan.nextInt();
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				product = new Product(productId, productName, productPrice, productCategory);
				products.put(productId, product);
				System.out.println("Product Saved Successfully");
				break;
			case 2:
				System.out.println("Enter Details To Update Product ");
				System.out.println("Enter Exsisting ProductId:");
				productId = scan.nextInt();
				System.out.println("Enter ProductName:");
				productName = scan.next();
				System.out.println("Enter ProductPrice:");
				productPrice = scan.nextInt();
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				product = new Product(productId, productName, productPrice, productCategory);
				products.put(productId, product);
				System.out.println("Product Updated Successfully");
				break;
			case 3:
				System.out.println("Enter Details To Delete A Product ");
				System.out.println("Enter Exsisting ProductId:");
				productId = scan.nextInt();
				products.remove(productId);
				System.out.println("Product Deleted Successfully");
				break;
			case 4:
				System.out.println("Enter Details To Get A Product ");
				System.out.println("Enter Exsisting ProductId:");
				productId = scan.nextInt();
				product = products.get(productId);
				System.out.println(product);
				break;
			case 5:
				System.out.println("Products Info:");
				Set<Integer> keys = products.keySet();
				Iterator<Integer> itr = keys.iterator();
				while (itr.hasNext()) {
					int key = itr.next();
					System.out.println(products.get(key));
				}
				break;
			case 6:
				System.out.println("Products Info:");
				System.out.println("Enter ProductPrice:");
				int productInitailPrice = scan.nextInt();
				System.out.println("Enter ProductPrice:");
				int finalPrice = scan.nextInt();
				Set<Integer> keys1 = products.keySet();
				Iterator<Integer> itr1 = keys1.iterator();
				while (itr1.hasNext()) {
					int key = itr1.next();
					product = products.get(key);
					int oldPrice = product.getProductPrice();
					if (oldPrice >= productInitailPrice && oldPrice <= finalPrice)
						System.out.println(product);
				}
				break;
			case 7:
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				System.out.println("Products Info:");
				Set<Integer> keys2 = products.keySet();
				Iterator<Integer> itr2 = keys2.iterator();
				while (itr2.hasNext()) {
					int key = itr2.next();
					product = products.get(key);
					if (product.getProductCategory().equals(productCategory))
						System.out.println(product);
				}
				break;

			default:
				scan.close();
				System.out.println("Thank you !!!");
				System.exit(0);

				break;
			}
		}

	}

}
